"""
RoboDSL - A DSL for GPU-accelerated robotics applications with ROS2 and CUDA.
"""

__version__ = "0.1.0"
